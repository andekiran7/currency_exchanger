API_KEY = "e87d40ce1bd4e8984fd0935b"  
API_URL = f"https://v6.exchangerate-api.com/v6/{API_KEY}/latest/"
DATABASE_FILE = "currency_rates.db"
